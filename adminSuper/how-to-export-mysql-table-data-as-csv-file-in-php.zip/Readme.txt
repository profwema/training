Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/how-to-export-mysql-table-data-as-csv-file-in-php/

Instructions -

1. Import the attached users.sql file in your database
2. Update config.php file.